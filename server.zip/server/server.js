import express from 'express';
import cors from 'cors';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';
import { nanoid } from 'nanoid';
import path from 'path';
import { fileURLToPath } from 'url';
// __filename and __dirname for ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_key_change_me';

const app = express();
app.use(cors());
app.use(express.json());

// Serve frontend static files from project root so GET / returns index.html
app.use(express.static(path.join(__dirname, '..')));

// lowdb setup
const file = path.join(__dirname, 'db.json');
const adapter = new JSONFile(file);
const db = new Low(adapter);

async function initDb(){
  await db.read();
  db.data = db.data || { users: [] };
  await db.write();
}

initDb();

app.post('/api/register', async (req, res) => {
  console.log('/api/register called', (req.body && req.body.email) || 'no-email');
  const { nombre, apellido, email, password, pais, telefono } = req.body || {};
  if(!email || !password || !nombre) return res.status(400).json({ error: 'Missing fields' });
  await db.read();
  const exists = db.data.users.find(u => u.email === email.toLowerCase());
  if(exists) return res.status(409).json({ error: 'User exists' });
  const hash = await bcrypt.hash(password, 10);
  const user = { id: nanoid(), nombre, apellido, email: email.toLowerCase(), passwordHash: hash, pais: pais||'', telefono: telefono||'', createdAt: new Date().toISOString() };
  db.data.users.push(user);
  await db.write();
  res.json({ success: true, user: { id: user.id, email: user.email, nombre: user.nombre } });
});

app.post('/api/login', async (req, res) => {
  console.log('/api/login called', (req.body && req.body.email) || 'no-email');
  const { email, password } = req.body || {};
  if(!email || !password) return res.status(400).json({ error: 'Missing fields' });
  await db.read();
  const user = db.data.users.find(u => u.email === email.toLowerCase());
  if(!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if(!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, nombre: user.nombre, email: user.email } });
});

// protected example
app.get('/api/me', async (req, res) => {
  console.log('/api/me called');
  const auth = req.headers.authorization;
  if(!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
  const token = auth.split(' ')[1];
  try{
    const decoded = jwt.verify(token, JWT_SECRET);
    await db.read();
    const user = db.data.users.find(u=>u.id === decoded.id);
    if(!user) return res.status(401).json({ error: 'Unauthorized' });
    res.json({ id: user.id, nombre: user.nombre, email: user.email });
  }catch(err){
    return res.status(401).json({ error: 'Invalid token' });
  }
});


app.listen(PORT, ()=> console.log(`Auth server running on http://localhost:${PORT}`));
