(async ()=>{
  const base = 'http://localhost:4000';
  const unique = Date.now();
  const email = `autotest+${unique}@example.com`;
  try{
    console.log('Registering', email);
    let r = await fetch(base + '/api/register', {
      method: 'POST',
      headers: {'content-type':'application/json'},
      body: JSON.stringify({ nombre: 'Auto', apellido: 'Tester', email, password: 'Test1234' })
    });
    const reg = await r.json().catch(()=>({status:r.status}));
    console.log('Register response:', JSON.stringify(reg, null, 2));

    console.log('Logging in');
    r = await fetch(base + '/api/login', {
      method: 'POST',
      headers: {'content-type':'application/json'},
      body: JSON.stringify({ email, password: 'Test1234' })
    });
    const login = await r.json().catch(()=>({status:r.status}));
    console.log('Login response:', JSON.stringify(login, null, 2));

    if(!login.token){
      console.error('Login failed, aborting.');
      process.exit(2);
    }

    console.log('Calling /api/me with token');
    r = await fetch(base + '/api/me', { headers: { Authorization: 'Bearer ' + login.token }});
    const me = await r.json().catch(()=>({status:r.status}));
    console.log('/api/me response:', JSON.stringify(me, null, 2));

    console.log('Test completed successfully.');
    process.exit(0);
  }catch(err){
    console.error('Error during tests:', err);
    process.exit(1);
  }
})();
